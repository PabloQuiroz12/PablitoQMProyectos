package Multicenter;


import Multicenter.Categorias.*;

import java.util.Scanner;


public class GestionProductos extends Productos {
    static Scanner teclado =new Scanner(System.in);
    String moneda = " Bs";

    public static Electrodomesticos[] listaElectrodomesticos = new Electrodomesticos[3];
    public static Juguetes[] listaJuguetes = new Juguetes[3];
    public static Herramientas[] listaHerramientas = new Herramientas[3];
    public static Muebles[] listaMuebles = new Muebles[3];



    public void mostrarListaDeProductos(){
        int indice = 0;

        System.out.println("__________________________________________________________________________");
        System.out.println("BIENVENIDO(A) !!!");
        System.out.println("LISTA DE PRODUCTOS EN LA TIENDA:");

        System.out.println("\t");
        System.out.println("----JUGUETES----");

        for(int i=0 ; i<listaJuguetes.length ; i++){
            indice++;
            System.out.println(indice + ". " +listaJuguetes[i].getNombre()
                    + "   ||  "
                    + "Precio: " + listaJuguetes[i].getPrecio()
                    +moneda);
        }

        System.out.println("\t");
        System.out.println("----MUEBLES----");

        for(int i=0 ; i<listaMuebles.length ; i++){
            indice++;
            System.out.println(indice+". "+listaMuebles[i].getNombre()
                    + "   ||  "
                    + "Precio: " + listaMuebles[i].getPrecio()
                    +moneda);
        }

        System.out.println("\t");
        System.out.println("----ELECTRODOMESTICOS----");

        for(int i=0 ; i<listaElectrodomesticos.length ; i++){
            indice++;
            System.out.println(indice+". "+listaElectrodomesticos[i].getNombre()
                    + "   ||  "
                    + "Precio: " + listaElectrodomesticos[i].getPrecio()
                    +moneda);
        }

        System.out.println("\t");
        System.out.println("----HERRAMIENTAS----");

        for(int i=0 ; i<listaHerramientas.length ; i++){
            indice++;
            System.out.println(indice+". "+listaHerramientas[i].getNombre()
                    + "   ||  "
                    + "Precio: " + listaHerramientas[i].getPrecio()
                    +moneda);
        }
        System.out.println("__________________________________________________________________________");

    }


    public void agregarProd(){

        listaJuguetes[0]= new Juguetes("Ultimate Garage                   ", "Hot Wheels", 1600, "Estados Unidos", 2, 5,1, "Diversion");
        listaJuguetes[1]= new Juguetes("Pirámide de argollas eco          ", "Fisher Price", 80, "Estados Unidos", 2, 5,2, "Educativo");
        listaJuguetes[2] = new Juguetes("Ultra Scream Machine              ", "Nerf", 600, "Estados Unidos", 2, 5,3, "Diversion");


        listaMuebles[0] = new Muebles("Sofá Cama                         ","Palermo",3000,"Argentina",3,5,4,"Azul","Tapizado en tela","Sala de estar");
        listaMuebles[1] = new Muebles("Mesa de Noche                     ","Fremont",500,"Estados Unidos",5,5,5,"Negro","Tablero aglomera","Dormitorio");
        listaMuebles[2]= new Muebles("Sofá Cama                         ","Palermo",3000,"Argentina",5,5,6,"Azul","Tapizado en tela","Sala de estar");


        listaElectrodomesticos[0]= new Electrodomesticos("Licuadora jarra pica hielo        ","Brügmann",350,"Alemania",5,5,7,"Negro","Vidrio","Pequenho","Cocina");
        listaElectrodomesticos[1] = new Electrodomesticos("Exprimidor de Cítricos profesional","Ufesa",500,"Francia",4,5,8,"Blanco","Acero","Pequenho","Cocina");
        listaElectrodomesticos[2] = new Electrodomesticos("Licuadora                         ","Philips",450,"Paises Bajos",5,5,9,"Rojo","Vidrio","Pequenho","Cocina");


        listaHerramientas[0]= new Herramientas("Taladro Inalambrico              ","Einhell",450,"Alemania",5,5,10,"Electrica","Plastico y metal");
        listaHerramientas[1]= new Herramientas("Amoladora Angular                ","Makita",1900, "Japon",4,5,11,"Electrica","Plastico y metal");
        listaHerramientas[2] = new Herramientas("Hidrolavadora                   ","Karcher",2300,"Alemania",5,5,12,"Automotriz","Plastico");


    }


    public void buscarProd(){
        boolean control = true;
        while (control){
         try {
         System.out.print("INGRESE EL INDICE DEL PRODUCTO QUE DESEA BUSCAR: ");
         int iD = Integer.parseInt(teclado.nextLine());
          System.out.println();
             for (int i=0;i<3;i++)
                 if (listaJuguetes[i].getId() == iD) {
                     System.out.println("\t");
                     System.out.println("EL PRODUCTO BUSCADO ES: "
                             + listaJuguetes[i].getNombre()
                             + " ("+listaHerramientas[i].getPrecio()
                             + moneda+")");
                     System.out.println("Marca: "+ listaJuguetes[i].getMarca());
                     System.out.println("Industria: "+ listaJuguetes[i].getIndustria());
                     System.out.println("Stock: "+ listaJuguetes[i].getStock());
                     control = false;
                 }
             for (int i=0;i<3;i++){
                 if (listaMuebles[i].getId() == iD){
                    System.out.println("\t");
                    System.out.println("Su producto es: "
                            + listaMuebles[i].getNombre()
                            + " ("+listaHerramientas[i].getPrecio()
                            + moneda+")");
                     System.out.println("Marca: "+ listaMuebles[i].getMarca());
                     System.out.println("Industria: "+ listaMuebles[i].getIndustria());
                     System.out.println("Stock: "+ listaMuebles[i].getStock());
                    control = false;
                }
             }
             for (int i=0;i<3;i++){
                if (listaElectrodomesticos[i].getId() == iD){
                    System.out.println("\t");
                    System.out.println("Su producto es: "
                            + listaElectrodomesticos[i].getNombre()
                            + " ("+listaHerramientas[i].getPrecio()
                            + moneda+")");
                    System.out.println("Marca: "+ listaElectrodomesticos[i].getMarca());
                    System.out.println("Industria: "+ listaElectrodomesticos[i].getIndustria());
                    System.out.println("Stock: "+ listaElectrodomesticos[i].getStock());
                    control = false;
                }
            }
             for (int i=0;i<3;i++){
                if (listaHerramientas[i].getId() == iD){
                    System.out.println("\t");
                    System.out.println("Su producto es: "
                            + listaHerramientas[i].getNombre()
                            + " ("+listaHerramientas[i].getPrecio()
                            + moneda+")");
                    System.out.println("Marca: "+ listaHerramientas[i].getMarca());
                    System.out.println("Industria: "+ listaHerramientas[i].getIndustria());
                    System.out.println("Stock: "+ listaHerramientas[i].getStock());
                    control = false;
                }
            }


         }catch (NumberFormatException a){
             //a.printStackTrace();
             }
         }

    }



    public void obtenerProdSinStock(){
        System.out.println("\t");
        for (int i=0; i<listaJuguetes.length ; i++){
            if(listaJuguetes[i].getStock()==0){
                System.out.println("PRODUCTO SIN STOCK: "+listaJuguetes[i].getNombre());
            }
        }

        for (int i=0; i<listaMuebles.length ; i++){
            if(listaMuebles[i].getStock()==0){
                System.out.println("PRODUCTO SIN STOCK: "+listaMuebles[i].getNombre());
            }
        }

        for (int i=0; i<listaElectrodomesticos.length ; i++){
            if(listaElectrodomesticos[i].getStock()==0){
                System.out.println("PRODUCTO SIN STOCK: "+listaElectrodomesticos[i].getNombre());
            }
        }

        for (int i=0; i<listaHerramientas.length ; i++){
            if(listaHerramientas[i].getStock()==0){
                System.out.println("PRODUCTO SIN STOCK: "+listaHerramientas[i].getNombre());
            }
        }
    }
}
