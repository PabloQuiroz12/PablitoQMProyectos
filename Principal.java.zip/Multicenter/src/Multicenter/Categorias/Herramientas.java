package Multicenter.Categorias;

import Multicenter.Productos;

public class Herramientas extends Productos {
    private String tipoHerramienta;
    private String material;

    public Herramientas(String nombre, String marca, int precio, String industria, int garantia, int stock,int id, String tipoHerramienta, String material) {
        super(nombre, marca, precio, industria, garantia, stock,id);
        this.tipoHerramienta = tipoHerramienta;
        this.material = material;
    }

    public String getTipoHerramienta() {
        return tipoHerramienta;
    }

    public void setTipoHerramienta(String tipoHerramienta) {
        this.tipoHerramienta = tipoHerramienta;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
}
