package Multicenter.Categorias;

import Multicenter.Productos;

public class Juguetes extends Productos {
    private String tipoDeUso;

    public Juguetes(String nombre, String marca, int precio, String industria, int garantia, int stock, int id, String tipoDeUso) {
        super(nombre, marca, precio, industria, garantia, stock,id);
        this.tipoDeUso = tipoDeUso;
    }



    public String getTipoDeUso() {
        return tipoDeUso;
    }

    public void setTipoDeUso(String tipoDeUso) {
        this.tipoDeUso = tipoDeUso;
    }
}
