import Multicenter.GestionProductos;
import Multicenter.Categorias.Juguetes;
import Multicenter.Productos;

import java.util.Scanner;

public class Principal {


    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);


        GestionProductos g = new GestionProductos();
        g.agregarProd();
        g.mostrarListaDeProductos();
        g.buscarProd();
        g.obtenerProdSinStock();


    }
}
